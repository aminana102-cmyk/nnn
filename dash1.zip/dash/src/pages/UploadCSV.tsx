import { useState } from 'react';
import { parseCSV } from '@/utils/csvParser';
import { addUser } from '@/services/users.service';
import toast from 'react-hot-toast';
import { ArrowUpTrayIcon, DocumentTextIcon } from '@heroicons/react/24/outline';

export default function UploadCSV() {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    setProgress(0);
    try {
      const users = await parseCSV(file);
      let successCount = 0;
      let mergedCount = 0;
      let errorCount = 0;

      for (let i = 0; i < users.length; i++) {
        try {
          // Cast to any because parseCSV returns Partial<User> which has email?
          // but addUser expects email to be required for checking existence.
          // parseCSV filters out rows without email, so we are safe.
          const result = await addUser(users[i] as any);
          if (result.type === 'merged') {
            mergedCount++;
          } else {
            successCount++;
          }
        } catch (error) {
          console.error("Error adding user:", error);
          errorCount++;
        }
        setProgress(Math.round(((i + 1) / users.length) * 100));
      }

      toast.success(`Processed: ${successCount} new, ${mergedCount} merged, ${errorCount} failed`);
      setFile(null);
      setProgress(0);
    } catch (error) {
      toast.error('Failed to read CSV file');
      console.error(error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-white">Upload CSV</h1>
      
      <div className="bg-gray-800 shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="max-w-xl mx-auto">
            <label className="block text-sm font-medium text-gray-400">
              Select CSV File
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md hover:border-indigo-500 transition-colors">
              <div className="space-y-1 text-center">
                {file ? (
                  <div className="flex flex-col items-center">
                    <DocumentTextIcon className="mx-auto h-12 w-12 text-indigo-400" />
                    <p className="text-sm text-gray-300 mt-2">{file.name}</p>
                    <button 
                      onClick={() => setFile(null)}
                      className="text-xs text-red-400 mt-2 hover:text-red-300 transition-colors"
                    >
                      Remove File
                    </button>
                  </div>
                ) : (
                  <>
                    <ArrowUpTrayIcon className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-400">
                      <label
                        htmlFor="file-upload"
                        className="relative cursor-pointer bg-gray-800 rounded-md font-medium text-indigo-400 hover:text-indigo-300 focus-within:outline-none"
                      >
                        <span>Upload a file</span>
                        <input
                          id="file-upload"
                          name="file-upload"
                          type="file"
                          accept=".csv"
                          className="sr-only"
                          onChange={handleFileChange}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      CSV up to 10MB
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
          
          {file && (
            <div className="mt-6 flex justify-center">
              <button
                onClick={handleUpload}
                disabled={uploading}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 transition-colors"
              >
                {uploading ? `Uploading... ${progress}%` : 'Start Processing'}
              </button>
            </div>
          )}

          <div className="mt-8">
            <h3 className="text-sm font-medium text-gray-400">Supported Plans:</h3>
            <p className="text-xs text-gray-500 mb-2">Free, Essential, Plus, Pro, Standard, Premium, VIP, Custom</p>
            
            <h3 className="text-sm font-medium text-gray-400 mt-4">Required CSV Format:</h3>
            <div className="mt-2 bg-gray-900 p-4 rounded-md overflow-x-auto">
              <code className="text-xs text-green-400">
                email,name,country,credit,plan,price,created<br/>
                user1@example.com,John Doe,USA,100,Essential,29.99,2024-01-01<br/>
                user2@example.com,Jane Smith,UK,500,VIP,99.99,2024-02-15
              </code>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
