import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, serverTimestamp, query, where, orderBy, writeBatch, Timestamp } from 'firebase/firestore';
import { db } from './firebase';
import { User, Payment } from '@/types';

const COLLECTION_NAME = 'users';

export const getUsers = async (): Promise<User[]> => {
  const usersRef = collection(db, COLLECTION_NAME);
  const snapshot = await getDocs(usersRef);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));
};

export const addUser = async (userData: Omit<User, 'id' | 'registrationDate'> & { registrationDate?: Timestamp }): Promise<{ type: 'added' | 'merged', id: string }> => {
  const usersRef = collection(db, COLLECTION_NAME);
  
  // Check for existing user with same email
  const q = query(usersRef, where("email", "==", userData.email));
  const querySnapshot = await getDocs(q);

  if (!querySnapshot.empty) {
    // User exists - Merge
    const existingUserDoc = querySnapshot.docs[0];
    const existingUserData = existingUserDoc.data() as User;
    
    const newCredit = (Number(existingUserData.credit) || 0) + (Number(userData.credit) || 0);
    const lastPrice = Number(userData.price) || 0; 
    
    await updateDoc(existingUserDoc.ref, {
      credit: newCredit,
      price: lastPrice,
      // Update other info to latest provided values
      name: userData.name || existingUserData.name,
      country: userData.country || existingUserData.country,
      phone: userData.phone || existingUserData.phone,
      plan: userData.plan || existingUserData.plan,
      profileComplete: userData.profileComplete ?? existingUserData.profileComplete
      // Note: We typically do NOT update registrationDate for existing users
    });

    // Add record to payments sub-collection
    const paymentsRef = collection(existingUserDoc.ref, 'payments');
    await addDoc(paymentsRef, {
      amount: lastPrice,
      credit: Number(userData.credit) || 0,
      plan: userData.plan || existingUserData.plan,
      // Use the provided date for the payment if available, otherwise serverTimestamp
      date: userData.registrationDate || serverTimestamp() 
    });

    return { type: 'merged', id: existingUserDoc.id };
  } else {
    // New User
    // If registrationDate is provided in userData (from CSV), use it. Otherwise use serverTimestamp.
    const finalRegistrationDate = userData.registrationDate || serverTimestamp();

    const docRef = await addDoc(usersRef, {
      ...userData,
      registrationDate: finalRegistrationDate
    });

    // Add initial payment record
    const paymentsRef = collection(docRef, 'payments');
    await addDoc(paymentsRef, {
      amount: Number(userData.price) || 0,
      credit: Number(userData.credit) || 0,
      plan: userData.plan,
      date: finalRegistrationDate // Use the same date for the initial payment
    });

    return { type: 'added', id: docRef.id };
  }
};

export const updateUser = async (userId: string, userData: Partial<User>): Promise<void> => {
  const userRef = doc(db, COLLECTION_NAME, userId);
  await updateDoc(userRef, userData);
};

export const deleteUser = async (userId: string): Promise<void> => {
  const userRef = doc(db, COLLECTION_NAME, userId);
  await deleteDoc(userRef);
};

export const deleteUsersBulk = async (userIds: string[]): Promise<void> => {
  // Firestore batches allow up to 500 operations
  const batchSize = 500;
  for (let i = 0; i < userIds.length; i += batchSize) {
    const batch = writeBatch(db);
    const chunk = userIds.slice(i, i + batchSize);
    
    chunk.forEach(userId => {
      const userRef = doc(db, COLLECTION_NAME, userId);
      batch.delete(userRef);
    });
    
    await batch.commit();
  }
};

export const getUserPayments = async (userId: string): Promise<Payment[]> => {
  const paymentsRef = collection(db, COLLECTION_NAME, userId, 'payments');
  const q = query(paymentsRef, orderBy('date', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Payment));
};
