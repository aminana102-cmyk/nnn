import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "studio-4754082461-95b73",
  appId: "1:1091167191027:web:f0bc8cd05854303884dc86",
  apiKey: "AIzaSyAzNZCXiVQXsz8J61_C0aeBK54N3YpMrI8",
  authDomain: "studio-4754082461-95b73.firebaseapp.com",
  messagingSenderId: "1091167191027"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Use initializeFirestore to enable experimentalForceLongPolling
// This helps with connection issues behind proxies or restrictive networks
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
