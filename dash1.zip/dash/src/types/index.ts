import { Timestamp } from 'firebase/firestore';

export type UserPlan = 'Free' | 'Essential' | 'Plus' | 'Pro' | 'Standard' | 'Premium' | 'VIP' | 'Custom';

export interface User {
  id: string;
  email: string;
  name: string;
  country: string;
  phone: string;
  credit: number;
  plan: UserPlan;
  price: number;
  registrationDate: Timestamp;
  profileComplete: boolean;
}

export interface Payment {
  id: string;
  amount: number;
  credit: number;
  plan: string;
  date: Timestamp;
}
