import { NavLink } from 'react-router-dom';
import { HomeIcon, UsersIcon, Cog6ToothIcon, ArrowUpTrayIcon } from '@heroicons/react/24/outline';
import clsx from 'clsx';

const navigation = [
  { name: 'Dashboard', href: '/', icon: HomeIcon },
  { name: 'Users', href: '/users', icon: UsersIcon },
  { name: 'Upload CSV', href: '/upload-csv', icon: ArrowUpTrayIcon },
  { name: 'Settings', href: '/settings', icon: Cog6ToothIcon },
];

export default function Sidebar() {
  return (
    <div className="hidden md:flex md:w-72 md:flex-col md:fixed md:inset-y-0 md:left-0 z-50">
      <div className="flex-1 flex flex-col min-h-0 bg-gray-900/90 backdrop-blur-xl border-r border-gray-800 shadow-2xl">
        <div className="flex items-center h-24 flex-shrink-0 px-6 bg-gradient-to-br from-gray-900 to-gray-800 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <span className="text-white font-bold text-xl">P</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-wide">Perchance AI</h1>
              <p className="text-xs text-gray-400">Admin Panel</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className={({ isActive }) =>
                clsx(
                  isActive 
                    ? 'bg-indigo-600/10 text-indigo-400 border-l-4 border-indigo-500' 
                    : 'text-gray-400 hover:bg-gray-800/50 hover:text-white border-l-4 border-transparent',
                  'group flex items-center px-4 py-3.5 text-sm font-medium rounded-r-xl transition-all duration-200'
                )
              }
            >
              <item.icon 
                className={clsx(
                  "mr-3 flex-shrink-0 h-6 w-6 transition-colors duration-200",
                )} 
                aria-hidden="true" 
              />
              <span className="text-base">{item.name}</span>
            </NavLink>
          ))}
        </nav>
        
        <div className="p-4 border-t border-gray-800 bg-gray-900/50">
          <div className="flex items-center gap-3 px-2">
            <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center border border-gray-600">
              <span className="text-xs text-gray-300">A</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">Admin</p>
              <p className="text-xs text-gray-500 truncate">Online</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
