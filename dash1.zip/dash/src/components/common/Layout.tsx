import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import { useAuth } from '@/context/AuthContext';
import { signOut } from 'firebase/auth';
import { auth } from '@/services/firebase';
import { ArrowRightOnRectangleIcon, BellIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';

export default function Layout() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-[#0f172a] relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-900/20 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-[120px]"></div>
      </div>

      <Sidebar />
      
      <div className="md:pl-72 flex flex-col min-h-screen relative z-10 transition-all duration-300">
        <header className="h-20 flex items-center justify-between px-8 bg-gray-900/50 backdrop-blur-md sticky top-0 z-40 border-b border-gray-800">
          <div className="flex-1 flex items-center max-w-lg">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MagnifyingGlassIcon className="h-5 w-5 text-gray-500" aria-hidden="true" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-4 py-2 border-none rounded-xl leading-5 bg-gray-800/50 text-gray-300 placeholder-gray-500 focus:outline-none focus:bg-gray-800 focus:ring-2 focus:ring-indigo-500/50 sm:text-sm transition-all duration-200"
                placeholder="Quick search..."
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="p-2 rounded-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors relative">
              <span className="absolute top-2 right-2 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-gray-900"></span>
              <BellIcon className="h-6 w-6" />
            </button>
            
            <div className="h-8 w-px bg-gray-700 mx-2"></div>
            
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-white">{user?.email?.split('@')[0]}</p>
                <p className="text-xs text-gray-400">Admin</p>
              </div>
              <button
                onClick={() => signOut(auth)}
                className="p-2 rounded-xl bg-gray-800 text-gray-400 hover:text-white hover:bg-red-500/10 hover:text-red-500 transition-all duration-200"
                title="Sign out"
              >
                <ArrowRightOnRectangleIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 p-8 overflow-y-auto">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
