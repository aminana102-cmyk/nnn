import { useState, useEffect } from 'react';
import { User } from '@/types';
import { getUsers, addUser, updateUser, deleteUser, deleteUsersBulk } from '@/services/users.service';
import UserForm from '@/components/users/UserForm';
import PaymentHistoryModal from '@/components/users/PaymentHistoryModal';
import { PlusIcon, PencilSquareIcon, TrashIcon, ClockIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function Users() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modals state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // Selection state
  const [selectedUserIds, setSelectedUserIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const data = await getUsers();
      setUsers(data);
    } catch (error) {
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = async (userData: Partial<User>) => {
    try {
      const result = await addUser(userData as any);
      if (result.type === 'merged') {
        toast.success('User exists! Payment added to history & Credit updated.');
      } else {
        toast.success('User added successfully');
      }
      fetchUsers();
    } catch (error: any) {
      console.error(error);
      toast.error('Failed to add user: ' + (error.message || 'Unknown error'));
    }
  };

  const handleUpdateUser = async (userData: Partial<User>) => {
    if (!selectedUser) return;
    try {
      await updateUser(selectedUser.id, userData);
      toast.success('User updated successfully');
      fetchUsers();
    } catch (error: any) {
      console.error(error);
      toast.error('Failed to update user: ' + (error.message || 'Unknown error'));
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        await deleteUser(userId);
        toast.success('User deleted successfully');
        fetchUsers();
      } catch (error: any) {
        console.error("Delete error:", error);
        toast.error('Failed to delete user: ' + (error.message || 'Check permissions'));
      }
    }
  };

  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Bulk Selection Logic
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      const allIds = new Set(filteredUsers.map(u => u.id));
      setSelectedUserIds(allIds);
    } else {
      setSelectedUserIds(new Set());
    }
  };

  const handleSelectUser = (userId: string) => {
    const newSelected = new Set(selectedUserIds);
    if (newSelected.has(userId)) {
      newSelected.delete(userId);
    } else {
      newSelected.add(userId);
    }
    setSelectedUserIds(newSelected);
  };

  const handleDeleteSelected = async () => {
    if (selectedUserIds.size === 0) return;
    
    if (window.confirm(`Are you sure you want to delete ${selectedUserIds.size} users? This action cannot be undone.`)) {
      try {
        setLoading(true);
        await deleteUsersBulk(Array.from(selectedUserIds));
        toast.success(`Successfully deleted ${selectedUserIds.size} users`);
        setSelectedUserIds(new Set());
        fetchUsers();
      } catch (error: any) {
        console.error("Bulk delete error:", error);
        toast.error('Failed to delete selected users: ' + (error.message || 'Check permissions'));
      } finally {
        setLoading(false);
      }
    }
  };

  const isAllSelected = filteredUsers.length > 0 && selectedUserIds.size === filteredUsers.length;
  const isIndeterminate = selectedUserIds.size > 0 && selectedUserIds.size < filteredUsers.length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-white">User Management</h1>
        <div className="flex gap-3">
          {selectedUserIds.size > 0 && (
            <button
              onClick={handleDeleteSelected}
              className="inline-flex items-center px-4 py-2 border border-red-500/30 text-sm font-medium rounded-md shadow-sm text-red-400 bg-red-500/10 hover:bg-red-500/20 transition-colors"
            >
              <TrashIcon className="h-5 w-5 mr-2" />
              Delete Selected ({selectedUserIds.size})
            </button>
          )}
          <button
            onClick={() => {
              setSelectedUser(null);
              setIsFormOpen(true);
            }}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-colors"
          >
            <PlusIcon className="h-5 w-5 mr-2" />
            Add User
          </button>
        </div>
      </div>

      <div className="bg-gray-800 shadow rounded-lg p-4">
        <input
          type="text"
          placeholder="Search by name or email..."
          className="block w-full rounded-md border-gray-600 bg-gray-700 text-white shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-4 py-2 transition-colors"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="bg-gray-800 shadow rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-900">
              <tr>
                <th scope="col" className="px-6 py-3 text-left">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-indigo-600 focus:ring-indigo-500 focus:ring-offset-gray-900"
                      checked={isAllSelected}
                      ref={input => {
                        if (input) input.indeterminate = isIndeterminate;
                      }}
                      onChange={handleSelectAll}
                    />
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Last Plan</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Total Credit</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Last Payment</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-gray-800 divide-y divide-gray-700">
              {filteredUsers.map((user) => (
                <tr key={user.id} className={`hover:bg-gray-700/50 transition-colors ${selectedUserIds.has(user.id) ? 'bg-indigo-900/20' : ''}`}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-indigo-600 focus:ring-indigo-500 focus:ring-offset-gray-900"
                        checked={selectedUserIds.has(user.id)}
                        onChange={() => handleSelectUser(user.id)}
                      />
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">{user.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.plan === 'Premium' ? 'bg-yellow-100 text-yellow-800' : 
                      user.plan === 'Pro' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.plan}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-indigo-300 font-medium">{user.credit}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">${user.price || 0}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => {
                        setSelectedUser(user);
                        setIsHistoryOpen(true);
                      }}
                      className="text-blue-400 hover:text-blue-300 mr-4 transition-colors"
                      title="View Payment History"
                    >
                      <ClockIcon className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => {
                        setSelectedUser(user);
                        setIsFormOpen(true);
                      }}
                      className="text-indigo-400 hover:text-indigo-300 mr-4 transition-colors"
                      title="Edit User"
                    >
                      <PencilSquareIcon className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="text-red-400 hover:text-red-300 transition-colors"
                      title="Delete User"
                    >
                      <TrashIcon className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <UserForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSubmit={selectedUser ? handleUpdateUser : handleAddUser}
        initialData={selectedUser}
      />

      <PaymentHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        user={selectedUser}
      />
    </div>
  );
}
