import { useEffect, useState } from 'react';
import { collection, getDocs, query, orderBy, limit } from 'firebase/firestore';
import { db } from '@/services/firebase';
import { User } from '@/types';
import { 
  UsersIcon, 
  CurrencyDollarIcon, 
  UserPlusIcon, 
  ArrowTrendingUpIcon,
  ChartBarIcon
} from '@heroicons/react/24/outline';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend
} from 'recharts';

// Colors for charts
const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b', '#ef4444', '#3b82f6'];

export default function Dashboard() {
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalCredit, setTotalCredit] = useState(0);
  const [recentUsers, setRecentUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Chart Data States
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [planData, setPlanData] = useState<any[]>([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const usersRef = collection(db, 'users');
        
        // Fetch all users for aggregations
        // In a real large-scale app, we would use server-side aggregation functions
        const allDocsSnapshot = await getDocs(usersRef);
        const users = allDocsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));

        // 1. Calculate Totals
        const revenue = users.reduce((acc, user) => acc + (Number(user.price) || 0), 0);
        const credit = users.reduce((acc, user) => acc + (Number(user.credit) || 0), 0);
        
        setTotalUsers(users.length);
        setTotalRevenue(revenue);
        setTotalCredit(credit);

        // 2. Process Monthly Data (Revenue & Growth)
        const monthlyStats = new Map<string, { name: string, revenue: number, users: number, sortKey: number }>();
        
        users.forEach(user => {
          if (user.registrationDate) {
            const date = user.registrationDate.toDate();
            const monthKey = `${date.getFullYear()}-${date.getMonth()}`; // unique key
            const monthName = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            
            if (!monthlyStats.has(monthKey)) {
              monthlyStats.set(monthKey, { 
                name: monthName, 
                revenue: 0, 
                users: 0,
                sortKey: date.getTime() 
              });
            }
            
            const stat = monthlyStats.get(monthKey)!;
            stat.revenue += Number(user.price) || 0;
            stat.users += 1;
          }
        });

        const sortedMonthlyData = Array.from(monthlyStats.values())
          .sort((a, b) => a.sortKey - b.sortKey)
          .map(({ sortKey, ...rest }) => rest); // remove sortKey for clean chart data

        setMonthlyData(sortedMonthlyData);

        // 3. Process Plan Distribution
        const planCounts = new Map<string, number>();
        users.forEach(user => {
          const plan = user.plan || 'Free';
          planCounts.set(plan, (planCounts.get(plan) || 0) + 1);
        });

        const sortedPlanData = Array.from(planCounts.entries())
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value); // Sort by count desc

        setPlanData(sortedPlanData);

        // 4. Fetch Recent Users (Limited)
        // We can just slice the already sorted/fetched array if we want, or re-query for strictness
        // Let's re-query to ensure we respect DB order perfectly
        const recentQuery = query(usersRef, orderBy('registrationDate', 'desc'), limit(5));
        const recentSnapshot = await getDocs(recentQuery);
        setRecentUsers(recentSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User)));

      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const stats = [
    { name: 'Total Users', value: totalUsers, icon: UsersIcon, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { name: 'Total Revenue', value: `$${totalRevenue.toLocaleString()}`, icon: CurrencyDollarIcon, color: 'text-green-500', bg: 'bg-green-500/10' }, 
    { name: 'Total Credit', value: totalCredit.toLocaleString(), icon: UserPlusIcon, color: 'text-purple-500', bg: 'bg-purple-500/10' }, 
  ];

  if (loading) return (
    <div className="flex items-center justify-center h-full min-h-[400px]">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500"></div>
    </div>
  );

  return (
    <div className="space-y-8 pb-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Dashboard Overview</h1>
          <p className="text-gray-400">Welcome back! Here's what's happening with your platform.</p>
        </div>
        <div className="hidden sm:block">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <ArrowTrendingUpIcon className="w-4 h-4 mr-2" />
            Live Data
          </span>
        </div>
      </div>
      
      {/* Key Stats Grid */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
        {stats.map((item) => (
          <div key={item.name} className="glass-card p-6 flex items-center hover:scale-[1.02] transition-transform duration-200">
            <div className={`p-4 rounded-xl ${item.bg} mr-5`}>
              <item.icon className={`h-8 w-8 ${item.color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-400">{item.name}</p>
              <p className="text-2xl font-bold text-white mt-1">{item.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart: Revenue & Growth */}
        <div className="glass-card p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">Revenue & User Growth</h3>
            <ChartBarIcon className="h-5 w-5 text-gray-400" />
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#9ca3af" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  yAxisId="left" 
                  stroke="#9ca3af" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false}
                  tickFormatter={(value) => `$${value}`}
                />
                <YAxis 
                  yAxisId="right" 
                  orientation="right" 
                  stroke="#9ca3af" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', borderColor: '#374151', color: '#fff' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Legend />
                <Area 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="revenue" 
                  name="Revenue" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorRevenue)" 
                />
                <Area 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="users" 
                  name="New Users" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorUsers)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Side Chart: Plan Distribution */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Plan Distribution</h3>
          <div className="h-[300px] w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={planData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {planData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', borderColor: '#374151', color: '#fff' }}
                />
                <Legend 
                  layout="horizontal" 
                  verticalAlign="bottom" 
                  align="center"
                  wrapperStyle={{ paddingTop: '20px' }}
                />
              </PieChart>
            </ResponsiveContainer>
            {/* Center Text for Donut */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-8">
              <span className="text-3xl font-bold text-white">{totalUsers}</span>
              <span className="text-xs text-gray-400">Users</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Users Section */}
      <div className="glass-card">
        <div className="px-6 py-5 border-b border-gray-700/50 flex items-center justify-between">
          <h3 className="text-lg leading-6 font-medium text-white">Recent Transactions & Users</h3>
          <a href="/users" className="text-sm text-indigo-400 hover:text-indigo-300">View All &rarr;</a>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700/50">
            <thead className="bg-gray-800/30">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Plan</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700/50">
              {recentUsers.map((user) => (
                <tr key={user.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-br from-gray-700 to-gray-600 flex items-center justify-center text-white font-bold text-xs">
                        {user.name?.charAt(0).toUpperCase()}
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-white">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.plan === 'VIP' || user.plan === 'Premium' ? 'bg-purple-500/10 text-purple-400' : 
                      user.plan === 'Pro' ? 'bg-indigo-500/10 text-indigo-400' : 'bg-gray-500/10 text-gray-400'
                    }`}>
                      {user.plan}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-white font-medium">
                    ${user.price?.toLocaleString() || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                    {user.registrationDate?.toDate().toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
