import Papa from 'papaparse';
import { User, UserPlan } from '@/types';
import { Timestamp } from 'firebase/firestore';

export const parseCSV = (file: File): Promise<Partial<User>[]> => {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim().toLowerCase(), 
      complete: (results) => {
        if (results.errors.length > 0) {
          console.warn("CSV parsing errors:", results.errors);
          if (results.data.length === 0) {
            reject(results.errors);
            return;
          }
        }

        const validUsers: Partial<User>[] = [];

        results.data.forEach((row: any) => {
          // Normalize email: trim and lowercase
          const email = row.email?.trim()?.toLowerCase();
          
          // Skip rows without email as it's our unique identifier
          if (!email) return;

          // Robust Plan Normalization
          let plan: UserPlan = 'Free';
          const rawPlan = row.plan?.trim()?.toLowerCase() || '';
          
          if (rawPlan.includes('essantial') || rawPlan.includes('essential')) plan = 'Essential';
          else if (rawPlan === 'plus') plan = 'Plus';
          else if (rawPlan === 'pro') plan = 'Pro';
          else if (rawPlan.includes('standar')) plan = 'Standard';
          else if (rawPlan === 'vip') plan = 'VIP';
          else if (rawPlan === 'custom') plan = 'Custom';
          else if (rawPlan === 'premium') plan = 'Premium';

          // Normalize Boolean for profileComplete
          const rawComplete = row.profilecomplete?.toString()?.toLowerCase()?.trim();
          const profileComplete = rawComplete === 'true' || rawComplete === 'yes' || rawComplete === '1';

          // Clean numbers
          const cleanNumber = (val: any) => {
            if (typeof val === 'number') return val;
            if (!val) return 0;
            const cleaned = val.toString().replace(/[^0-9.-]+/g, "");
            const num = Number(cleaned);
            return isNaN(num) ? 0 : num;
          };

          const credit = cleanNumber(row.credit);
          const price = cleanNumber(row.price);

          // Name fallback
          const name = row.name?.trim() || row.fullname?.trim() || row['full name']?.trim() || 'Unknown';

          // Parse created/date field
          let registrationDate: any = null;
          if (row.created) registrationDate = new Date(row.created);
          else if (row.date) registrationDate = new Date(row.date);
          
          // If invalid date, it will be null, and service will handle it (or use current time)

          validUsers.push({
            name: name,
            email: email,
            country: row.country?.trim() || row.countr?.trim() || '', // Handle 'countr' typo
            phone: '', // Ignored as requested
            credit: credit,
            plan: plan,
            price: price,
            profileComplete: profileComplete,
            // We pass the parsed date if valid. If invalid/missing, it's undefined
            // and the service will set serverTimestamp() for NEW users.
            // For EXISTING users, we don't update registrationDate usually.
            ...(registrationDate && !isNaN(registrationDate.getTime()) ? { registrationDate: Timestamp.fromDate(registrationDate) } : {}) 
          } as any);
        });

        resolve(validUsers);
      },
      error: (error) => {
        reject(error);
      }
    });
  });
};
