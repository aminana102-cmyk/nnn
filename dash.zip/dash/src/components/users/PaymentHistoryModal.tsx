import { Fragment, useEffect, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Payment, User } from '@/types';
import { getUserPayments } from '@/services/users.service';

interface PaymentHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
}

export default function PaymentHistoryModal({ isOpen, onClose, user }: PaymentHistoryModalProps) {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user && isOpen) {
      setLoading(true);
      getUserPayments(user.id)
        .then(setPayments)
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [user, isOpen]);

  return (
    <Transition show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity" />
        </Transition.Child>

        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative transform overflow-hidden rounded-2xl bg-gray-900 border border-gray-800 text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-2xl">
                <div className="bg-gray-800/50 px-6 py-4 border-b border-gray-700/50 flex justify-between items-center">
                  <Dialog.Title as="h3" className="text-xl font-semibold leading-6 text-white">
                    Payment History
                  </Dialog.Title>
                  <span className="text-sm text-gray-400">{user?.email}</span>
                </div>
                
                <div className="px-6 py-6 max-h-[60vh] overflow-y-auto">
                  {loading ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
                    </div>
                  ) : payments.length > 0 ? (
                    <table className="min-w-full divide-y divide-gray-700">
                      <thead>
                        <tr>
                          <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-400">Date</th>
                          <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-400">Plan</th>
                          <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-400">Amount</th>
                          <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-400">Credit Added</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800">
                        {payments.map((payment) => (
                          <tr key={payment.id}>
                            <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-300">
                              {payment.date?.toDate().toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                payment.plan === 'Premium' ? 'bg-yellow-500/10 text-yellow-400' :
                                payment.plan === 'Pro' ? 'bg-green-500/10 text-green-400' :
                                'bg-gray-500/10 text-gray-400'
                              }`}>
                                {payment.plan}
                              </span>
                            </td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm text-white font-medium">
                              ${payment.amount}
                            </td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm text-indigo-400">
                              +{payment.credit}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <p className="text-center text-gray-500 py-8">No payment history found.</p>
                  )}
                </div>

                <div className="bg-gray-800/50 px-6 py-4 sm:flex sm:flex-row-reverse border-t border-gray-700/50">
                  <button
                    type="button"
                    className="mt-3 inline-flex w-full justify-center rounded-lg bg-gray-700 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-600 sm:mt-0 sm:w-auto"
                    onClick={onClose}
                  >
                    Close
                  </button>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}
